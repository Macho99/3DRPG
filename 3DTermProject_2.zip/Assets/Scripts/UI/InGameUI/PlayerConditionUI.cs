using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerConditionUI : InGameUI
{
    protected override void Init()
    {
        throw new System.NotImplementedException();
    }
}
