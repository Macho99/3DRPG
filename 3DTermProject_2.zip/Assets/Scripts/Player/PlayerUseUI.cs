using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerUseUI : MonoBehaviour
{
    public bool onInteractionUI = false;
    public TestCube testCube = null;
}

