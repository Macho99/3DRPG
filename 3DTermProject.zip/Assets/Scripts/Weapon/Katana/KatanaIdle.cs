﻿using System.Collections.Generic;
using UnityEngine;

public class KatanaIdle : StateBase<Katana.State, Katana>
{
	public KatanaIdle(Katana owner, StateMachine<Katana.State, Katana> stateMachine) : base(owner, stateMachine)
	{

	}

	public override void Enter()
	{

	}

	public override void Exit()
	{

	}

	public override void Setup()
	{

	}

	public override void Transition()
	{

	}

	public override void Update()
	{

	}
}
