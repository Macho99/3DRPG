using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class InventorySlot : MonoBehaviour,
    IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    public Image iconImage;
    Transform iconParent;
    internal Item item = null;

    public Image highLight;

    private void Awake()
    {
        iconParent = iconImage.rectTransform.parent;
    }

    public virtual bool TrySetItem(Item item)
    {
        if (item == null) { return false; }
        this.item = item;
        iconImage.enabled = true;
        iconImage.sprite = item.itemIcon;
        return true;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        highLight.gameObject.SetActive(true);
        GameManager.Inven.focusSlot = this;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        highLight.gameObject.SetActive(false);
        GameManager.Inven.focusSlot = null;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log($"Click");
        GameManager.Inven.selectedSlot = this;
    }
}
