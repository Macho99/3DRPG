using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices.WindowsRuntime;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public RectTransform weaponContent;
    public RectTransform armorContent;
    public RectTransform consumContent;

    public InventoryUI inventoryUI;

    private List<InventorySlot> weaponList = new List<InventorySlot>();
    private List<InventorySlot> armorList = new List<InventorySlot>();
    private List<InventorySlot> consumList = new List<InventorySlot>();

    public InventorySlot focusSlot;
    public InventorySlot selectedSlot;

    private void Awake()
    {
        if(inventoryUI != null)
        {
            Destroy(inventoryUI);
        }
        inventoryUI = GameManager.Resource.Instantiate<InventoryUI>("UI/PopUpUI/Inventory/Inventory");
        MakeSlotParent();
    }

    public void MakeSlotParent()
    {
        weaponContent =
            GameManager.Resource.Instantiate<RectTransform>("UI/PopUpUI/Inventory/ItemList");
        weaponContent.gameObject.name = "WeaponList";
        MakeSlotsList(weaponList, weaponContent);
        weaponContent.transform.parent = inventoryUI.showItemArea.transform;

        armorContent =
            GameManager.Resource.Instantiate<RectTransform>("UI/PopUpUI/Inventory/ItemList");
        armorContent.gameObject.name = "ArmorList";
        MakeSlotsList(armorList, armorContent);
        armorContent.transform.parent = inventoryUI.showItemArea.transform;

        consumContent =
            GameManager.Resource.Instantiate<RectTransform>("UI/PopUpUI/Inventory/ItemList");
        consumContent.gameObject.name = "ConsumList";
        MakeSlotsList(consumList, consumContent);
        consumContent.transform.parent = inventoryUI.showItemArea.transform;
    }

    private void MakeSlotsList(List<InventorySlot> parentList, RectTransform parentTrans)
    {
        for (int i = 0; i < 4; i++)
        {
            var makeSlot = GameManager.Resource.Instantiate<InventorySlot>("UI/PopUpUI/Inventory/Slot", parentTrans.transform);
            makeSlot.name = $"{parentTrans.gameObject.name}_{i}";
            parentList.Add(makeSlot);
        }
    }

    public bool TryGainConsumItem(Consum item)
    {
        var emptySlot = consumList.Find((x) => { return x.item == null; });

        if(emptySlot == null)
        {
            return false;
        }

        return emptySlot.TrySetItem(item);
    }

    public bool TryGainArmorItem(Armor item)
    {
        var emptySlot = armorList.Find((x) => { return x.item == null; });

        if (emptySlot == null)
        {
            return false;
        }

        return emptySlot.TrySetItem(item);
    }
}
